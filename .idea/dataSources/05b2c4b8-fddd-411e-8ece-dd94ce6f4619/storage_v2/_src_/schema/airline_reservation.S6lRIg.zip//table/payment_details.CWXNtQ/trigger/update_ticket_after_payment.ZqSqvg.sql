create definer = root@localhost trigger update_ticket_after_payment
    after INSERT
    on payment_details
    for each row
    UPDATE ticket_details
     SET booking_status='CONFIRMED', payment_id= NEW.payment_id
   WHERE pnr = NEW.pnr;

